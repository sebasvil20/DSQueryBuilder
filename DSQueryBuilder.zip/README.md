# DSQueryBuilder
Chrome extension to build data suite queries

# Download & Install
Download from [releases](https://github.com/sebasvil20/DSQueryBuilder/releases) the last version and add the extension in Chrome browser.

To install the extension follow next steps:

Extensions > Manage extensions > Activate developer mode (Upper right corner) > Upload unpackaged extension > Select the unzipped folder

After that you can pin it to your toolbar

# What it looks like:
![](https://i.ibb.co/b7XVTJ6/UI.png)
